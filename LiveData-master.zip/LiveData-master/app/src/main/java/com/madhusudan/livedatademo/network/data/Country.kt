package com.madhusudan.livedatademo.network.data

class Country(val Countries: List<GlobalData>) {

}